<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('app.attachment.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('app.attachment.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="51">
    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KGH3DZ8C"
        height="0" width="0" style="display:none;visibility:hidden">
        </iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->


        <!-- Spinner Start -->
        <div
            id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div
            class="spinner-grow text-primary"
            style="width: 3rem; height: 3rem"
            role="status">
            <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

      <!-- Navbar & Hero Start -->
      <?php echo $__env->make('app.attachment.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Navbar & Hero End -->
      <?php echo $__env->yieldContent('content'); ?>

      <!-- Footer Start -->
      <?php echo $__env->make('app.attachment.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Footer End -->


      <!-- Back to Top -->
      <a href="https://wa.me/628569018937" target="_blank" class="btn btn-md back-to-top text-white pt-2"
        ><i class="bi bi-whatsapp"></i> Hubungi Bangor Care!</a>

    <?php echo $__env->make('app.attachment.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>
<?php /**PATH C:\Users\desai\Documents\WEBSITE\filament-laravel\filament-test\resources\views/app/layouts/front.blade.php ENDPATH**/ ?>