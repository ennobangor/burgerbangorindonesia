<?php

namespace App\Filament\Resources\PotraitCarouselResource\Pages;

use App\Filament\Resources\PotraitCarouselResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePotraitCarousel extends CreateRecord
{
    protected static string $resource = PotraitCarouselResource::class;
}
