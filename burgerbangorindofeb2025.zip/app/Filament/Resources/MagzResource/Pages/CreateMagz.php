<?php

namespace App\Filament\Resources\MagzResource\Pages;

use App\Filament\Resources\MagzResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMagz extends CreateRecord
{
    protected static string $resource = MagzResource::class;
}
